-- SECTION B:

======================================================================================================
-- cleaned data
-- =========================================================
-- CLEANED DATASET USED BY SECTIONS B-D
-- =========================================================

DROP VIEW IF EXISTS clean_transactions;
DROP VIEW IF EXISTS clean_transaction_lines;

CREATE TEMP VIEW clean_transactions AS
SELECT
    txn_id,
    txn_datetime,
    branch_id,
    customer_id,
    channel,
    payment_method,
    txn_type
FROM (
    SELECT
        t.*,
        ROW_NUMBER() OVER (
            PARTITION BY txn_id
            ORDER BY txn_datetime
        ) AS rn
    FROM transactions t
)
WHERE rn = 1
  -- Assessment reporting period
  AND date(txn_datetime) >= date('2025-01-01')
  AND date(txn_datetime) <  date('2026-07-01')
  -- Exclude QA/test branch
  AND branch_id <> 'B999'
  -- Exclude transactions after branch closure
  AND branch_id IN (
      SELECT b.branch_id
      FROM branches b
      WHERE b.close_date IS NULL
         OR date(txn_datetime) <= date(b.close_date)
  );

CREATE TEMP VIEW clean_transaction_lines AS
SELECT
    l.*
FROM transaction_lines l
JOIN clean_transactions t
    ON t.txn_id = l.txn_id
JOIN products p
    ON p.sku = l.sku
WHERE NOT (
    t.txn_type = 'Sale'
    AND l.is_return = 0
    AND (l.qty < 0 OR l.net_amount < 0)
);

-- B1
WITH regional_sales AS (
    SELECT
        b.region,

        SUM(
            CASE
                WHEN date(t.txn_datetime) >= date('2025-01-01')
                 AND date(t.txn_datetime) <  date('2025-07-01')
                THEN l.net_amount
                ELSE 0
            END
        ) AS net_sales_2025,

        SUM(
            CASE
                WHEN date(t.txn_datetime) >= date('2026-01-01')
                 AND date(t.txn_datetime) <  date('2026-07-01')
                THEN l.net_amount
                ELSE 0
            END
        ) AS net_sales_2026

    FROM clean_transaction_lines l
    JOIN clean_transactions t
        ON t.txn_id = l.txn_id
    JOIN branches b
        ON b.branch_id = t.branch_id
    GROUP BY b.region
)

SELECT
    region,
    ROUND(net_sales_2025, 2) AS net_sales_2025,
    ROUND(net_sales_2026, 2) AS net_sales_2026,
    ROUND(
        100.0 * (net_sales_2026 - net_sales_2025)
        / NULLIF(net_sales_2025, 0),
        1
    ) AS yoy_growth_pct
FROM regional_sales
ORDER BY yoy_growth_pct;

-- B2
SELECT
    l.sku,
    p.product_name,
    p.category,
    ROUND(SUM(l.net_amount), 2) AS net_sales,
    SUM(l.qty) AS units
FROM clean_transaction_lines l
JOIN clean_transactions t
    ON t.txn_id = l.txn_id
JOIN products p
    ON p.sku = l.sku
WHERE date(t.txn_datetime) >= date('2026-02-18')
  AND date(t.txn_datetime) <  date('2026-03-20')
GROUP BY
    l.sku,
    p.product_name,
    p.category
ORDER BY net_sales DESC
LIMIT 10;

-- B3
WITH channel_metrics AS (
    SELECT
        t.channel,

        COUNT(DISTINCT t.txn_id) AS transactions,

        SUM(l.net_amount) AS net_sales,

        SUM(l.qty) AS units

    FROM clean_transaction_lines l
    JOIN clean_transactions t
        ON t.txn_id = l.txn_id

    WHERE t.txn_type = 'Sale'
      AND date(t.txn_datetime) >= date('2026-01-01')
      AND date(t.txn_datetime) <  date('2026-07-01')

    GROUP BY t.channel
)

SELECT
    channel,
    transactions,
    ROUND(net_sales, 2) AS net_sales,
    ROUND(net_sales / NULLIF(transactions, 0), 2)
        AS average_basket_value,
    ROUND(units * 1.0 / NULLIF(transactions, 0), 2)
        AS upt
FROM channel_metrics
ORDER BY channel;

--Store is the largest channel by transaction volume and Net Sales, while average basket value and UPT are very similar across all three --channels. This suggests the main channel difference is sales volume rather than materially different basket size or units per transaction.

-- B4
WITH lfl_branches AS (
  SELECT branch_id
  FROM branches
  WHERE date(open_date) <= date('2025-01-01')
    AND (close_date IS NULL OR date(close_date) >= date('2026-06-30'))
),
lfl_agg AS (
  SELECT
    SUM(CASE WHEN strftime('%Y', t.txn_datetime) = '2025' AND strftime('%m', t.txn_datetime) <= '06' THEN 1 ELSE 0 END) AS lfl_2025,
    SUM(CASE WHEN strftime('%Y', t.txn_datetime) = '2026' AND strftime('%m', t.txn_datetime) <= '06' THEN 1 ELSE 0 END) AS lfl_2026
  FROM transactions t
  JOIN lfl_branches lb ON lb.branch_id = t.branch_id
),
total_agg AS (
  SELECT
    SUM(CASE WHEN strftime('%Y', t.txn_datetime) = '2025' AND strftime('%m', t.txn_datetime) <= '06' THEN 1 ELSE 0 END) AS total_2025,
    SUM(CASE WHEN strftime('%Y', t.txn_datetime) = '2026' AND strftime('%m', t.txn_datetime) <= '06' THEN 1 ELSE 0 END) AS total_2026
  FROM transactions t
)
SELECT
  (SELECT COUNT(*) FROM lfl_branches)                                        AS no_lfl_branches,
  lfl_agg.lfl_2025, lfl_agg.lfl_2026,
  ROUND((lfl_agg.lfl_2026 - lfl_agg.lfl_2025) * 100.0 / lfl_agg.lfl_2025, 1) AS lfl_growth_pct,
  total_agg.total_2025, total_agg.total_2026,
  ROUND((total_agg.total_2026 - total_agg.total_2025) * 100.0 / total_agg.total_2025, 1) AS total_growth_pct
FROM lfl_agg, total_agg;

-- B5(a)
SELECT
    strftime('%Y-%m', t.txn_datetime) AS month,
    COUNT(DISTINCT t.customer_id) AS active_customers
FROM clean_transactions t
WHERE t.txn_type = 'Sale'
  AND t.customer_id IS NOT NULL --mentioned in doc
  AND TRIM(t.customer_id) <> ''
  AND date(t.txn_datetime) >= date('2026-01-01')
  AND date(t.txn_datetime) <  date('2026-07-01')
GROUP BY strftime('%Y-%m', t.txn_datetime)
ORDER BY month;

-- B5(b)
WITH customer_frequency AS (
    SELECT
        customer_id,
        COUNT(DISTINCT txn_id) AS sale_transactions
    FROM clean_transactions
    WHERE txn_type = 'Sale'
      AND customer_id IS NOT NULL
      AND TRIM(customer_id) <> ''
      AND date(txn_datetime) >= date('2026-01-01')
      AND date(txn_datetime) <  date('2026-07-01')
    GROUP BY customer_id
)

SELECT
    COUNT(*) AS active_customers,

    SUM(
        CASE
            WHEN sale_transactions >= 2 THEN 1
            ELSE 0
        END
    ) AS repeat_customers,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN sale_transactions >= 2 THEN 1
                ELSE 0
            END
        ) / COUNT(*),
        2
    ) AS repeat_rate_pct
FROM customer_frequency;


