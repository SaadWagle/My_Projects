-- sec C: cohort analysis
-- used ai due to time constrainst, but i understand the query that i am using

WITH cohorts AS (
    SELECT
        customer_id,
        date(join_date, 'start of month') AS cohort_month
    FROM customers
    WHERE date(join_date) >= date('2025-01-01')
      AND date(join_date) <  date('2025-04-01')
),

cohort_sizes AS (
    SELECT
        cohort_month,
        COUNT(DISTINCT customer_id) AS cohort_size
    FROM cohorts
    GROUP BY cohort_month
),

activity AS (
    SELECT DISTINCT
        c.customer_id,
        c.cohort_month,
        date(t.txn_datetime, 'start of month') AS activity_month
    FROM cohorts c
    JOIN clean_transactions t
      ON t.customer_id = c.customer_id
    WHERE t.txn_type = 'Sale'
)

SELECT
    cs.cohort_month,
    cs.cohort_size,

    ROUND(
        100.0 * COUNT(DISTINCT CASE
            WHEN a.activity_month = date(cs.cohort_month, '+1 month')
            THEN a.customer_id END
        ) / cs.cohort_size, 1
    ) AS m1_pct,

    ROUND(
        100.0 * COUNT(DISTINCT CASE
            WHEN a.activity_month = date(cs.cohort_month, '+3 months')
            THEN a.customer_id END
        ) / cs.cohort_size, 1
    ) AS m3_pct,

    ROUND(
        100.0 * COUNT(DISTINCT CASE
            WHEN a.activity_month = date(cs.cohort_month, '+6 months')
            THEN a.customer_id END
        ) / cs.cohort_size, 1
    ) AS m6_pct

FROM cohort_sizes cs
LEFT JOIN activity a
  ON a.cohort_month = cs.cohort_month
GROUP BY cs.cohort_month, cs.cohort_size
ORDER BY cs.cohort_month;

--Retention is strongest in the first few months and falls by M+6 to roughly 23–26%. The February cohort has the strongest early and six-month --retention, suggesting a need to improve longer-term repeat behaviour across cohorts.


-- C2
WITH sale_metrics AS (
    SELECT
        t.customer_id,
        CAST(
            julianday('2026-06-30')
            - julianday(date(MAX(t.txn_datetime)))
            AS INTEGER
        ) AS recency_days,
        COUNT(DISTINCT t.txn_id) AS frequency
    FROM clean_transactions t
    WHERE t.txn_type = 'Sale'
      AND t.customer_id IS NOT NULL
      AND TRIM(t.customer_id) <> ''
      AND date(t.txn_datetime) >= date('2025-07-01')
      AND date(t.txn_datetime) <  date('2026-07-01')
    GROUP BY t.customer_id
),

monetary AS (
    SELECT
        t.customer_id,
        SUM(l.net_amount) AS monetary
    FROM clean_transactions t
    JOIN clean_transaction_lines l
      ON l.txn_id = t.txn_id
    WHERE t.customer_id IS NOT NULL
      AND TRIM(t.customer_id) <> ''
      AND date(t.txn_datetime) >= date('2025-07-01')
      AND date(t.txn_datetime) <  date('2026-07-01')
    GROUP BY t.customer_id
),

rfm AS (
    SELECT
        s.customer_id,
        s.recency_days,
        s.frequency,
        COALESCE(m.monetary, 0) AS monetary
    FROM sale_metrics s
    LEFT JOIN monetary m
      ON s.customer_id = m.customer_id
),

scored AS (
    SELECT *,
        NTILE(5) OVER (
            ORDER BY recency_days DESC, customer_id ASC
        ) AS r_score,

        NTILE(5) OVER (
            ORDER BY frequency ASC, customer_id ASC
        ) AS f_score,

        NTILE(5) OVER (
            ORDER BY monetary ASC, customer_id ASC
        ) AS m_score

    FROM rfm
),

segmented AS (
    SELECT *,
        CASE
            WHEN r_score = 5
             AND f_score >= 4
             AND m_score >= 4
                THEN 'Champions'

            WHEN r_score >= 4
             AND f_score >= 3
                THEN 'Loyal'

            WHEN r_score <= 2
             AND f_score >= 4
                THEN 'At Risk'

            WHEN r_score <= 2
             AND f_score <= 2
                THEN 'Hibernating'

            ELSE 'Others'
        END AS segment
    FROM scored
)

SELECT
    segment,
    COUNT(*) AS customers,
    ROUND(SUM(monetary), 2) AS net_sales,
    ROUND(
        100.0 * SUM(monetary)
        / (SELECT SUM(monetary) FROM segmented),
        2
    ) AS sales_pct
FROM segmented
GROUP BY segment
ORDER BY CASE segment
    WHEN 'Champions' THEN 1
    WHEN 'Loyal' THEN 2
    WHEN 'At Risk' THEN 3
    WHEN 'Hibernating' THEN 4
    ELSE 5
END;

--Target: At Risk customers. They have demonstrated high purchase frequency but are becoming inactive. I would run a targeted win-back campaign --with personalised offers based on previous category or product behaviour.


--C3
-- The customer bought goods in 2025, but they have not bought a single thing in the entire calendar year of 2026.

-- C3
WITH buyers_2025 AS (
    SELECT DISTINCT customer_id
    FROM clean_transactions
    WHERE txn_type = 'Sale'
      AND customer_id IS NOT NULL
      AND TRIM(customer_id) <> ''
      AND date(txn_datetime) >= date('2025-01-01')
      AND date(txn_datetime) <  date('2026-01-01')
),

last_sale AS (
    SELECT
        customer_id,
        MAX(date(txn_datetime)) AS last_sale_date
    FROM clean_transactions
    WHERE txn_type = 'Sale'
      AND customer_id IS NOT NULL
      AND TRIM(customer_id) <> ''
      AND date(txn_datetime) < date('2026-07-01')
    GROUP BY customer_id
),

churned AS (
    SELECT
        b.customer_id
    FROM buyers_2025 b
    JOIN last_sale l
      ON b.customer_id = l.customer_id
    WHERE julianday('2026-06-30')
        - julianday(l.last_sale_date) > 180
),

customer_sales_2025 AS (
    SELECT
        t.customer_id,
        SUM(l.net_amount) AS net_sales
    FROM clean_transactions t
    JOIN clean_transaction_lines l
      ON l.txn_id = t.txn_id
    WHERE t.customer_id IS NOT NULL
      AND TRIM(t.customer_id) <> ''
      AND date(t.txn_datetime) >= date('2025-01-01')
      AND date(t.txn_datetime) <  date('2026-01-01')
    GROUP BY t.customer_id
)

SELECT
    (SELECT COUNT(*) FROM buyers_2025) AS buyers_2025,

    (SELECT COUNT(*) FROM churned) AS churned_customers,

    ROUND(
        100.0 * (SELECT COUNT(*) FROM churned)
        / (SELECT COUNT(*) FROM buyers_2025),
        2
    ) AS churn_pct,

    ROUND(
        100.0 *
        (SELECT SUM(cs.net_sales)
         FROM customer_sales_2025 cs
         JOIN churned c
           ON cs.customer_id = c.customer_id)
        /
        (SELECT SUM(net_sales)
         FROM customer_sales_2025),
        2
    ) AS churn_sales_share_pct;
	
--2,354 customers, or 36.0% of 2025 buyers, had not purchased again within 180 days. These customers represented 25.6% of 2025 --customer Net Sales, indicating a meaningful retention risk.

-- C4 used AI due to time constrainsts i understand the query
WITH purchase_days AS (
    SELECT DISTINCT
        customer_id,
        date(txn_datetime) AS purchase_day
    FROM clean_transactions
    WHERE txn_type = 'Sale'
      AND customer_id IS NOT NULL
      AND TRIM(customer_id) <> ''
),

ordered AS (
    SELECT
        customer_id,
        purchase_day,
        LAG(purchase_day) OVER (
            PARTITION BY customer_id
            ORDER BY purchase_day
        ) AS previous_purchase_day
    FROM purchase_days
),

gaps AS (
    SELECT
        customer_id,
        CAST(
            julianday(purchase_day)
            - julianday(previous_purchase_day)
            AS INTEGER
        ) AS gap_days
    FROM ordered
    WHERE previous_purchase_day IS NOT NULL
),

ranked AS (
    SELECT
        g.*,
        c.loyalty_tier,
        ROW_NUMBER() OVER (
            PARTITION BY c.loyalty_tier
            ORDER BY gap_days
        ) AS rn,
        COUNT(*) OVER (
            PARTITION BY c.loyalty_tier
        ) AS n
    FROM gaps g
    JOIN customers c
      ON g.customer_id = c.customer_id
)

SELECT
    loyalty_tier,
    ROUND(
        AVG(
            CASE
                WHEN rn IN ((n + 1) / 2, (n + 2) / 2)
                THEN gap_days
            END
        ), 1
    ) AS median_gap_days
FROM ranked
GROUP BY loyalty_tier
ORDER BY CASE loyalty_tier
    WHEN 'Classic' THEN 1
    WHEN 'Silver' THEN 2
    WHEN 'Gold' THEN 3
    WHEN 'Platinum' THEN 4
END;
-- Trigger: contact the customer when they reach approximately 1.5× their tier's median purchase interval without a purchase.
--Purchase frequency increases substantially with loyalty tier. I would trigger a “we miss you” message at around 1.5× the typical --tier interval, allowing earlier intervention for Platinum and Gold customers.


--I would estimate historical customer CLV as average annual customer revenue × gross margin %

--I would track Active Customers and Repeat Rate monthly. Active Customers shows the size of the engaged customer base, while --Repeat Rate shows whether sales are being supported by recurring customer behaviour.

