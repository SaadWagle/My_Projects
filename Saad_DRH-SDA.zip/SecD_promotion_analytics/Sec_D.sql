-- D1 using ai due to time CONSTRAINTS

WITH daily AS (
    SELECT
        CASE
            WHEN p.category = 'Oud' THEN 'Oud'
            ELSE 'Other categories'
        END AS category_group,

        CASE
            WHEN date(t.txn_datetime) >= date('2026-02-18')
             AND date(t.txn_datetime) <  date('2026-03-20')
                THEN 'Promotion'
            ELSE 'Baseline'
        END AS period,

        date(t.txn_datetime) AS txn_date,
        SUM(l.net_amount) AS net_sales

    FROM clean_transaction_lines l
    JOIN clean_transactions t
      ON t.txn_id = l.txn_id
    JOIN products p
      ON p.sku = l.sku

    WHERE date(t.txn_datetime) >= date('2026-01-21')
      AND date(t.txn_datetime) <  date('2026-03-20')

    GROUP BY category_group, period, txn_date
),

summary AS (
    SELECT
        category_group,
        period,
        SUM(net_sales) AS net_sales,
        COUNT(*) AS days
    FROM daily
    GROUP BY category_group, period
)

SELECT
    category_group,
    period,
    ROUND(net_sales / days, 2) AS avg_daily_net_sales
FROM summary
ORDER BY category_group, period;

Oud average daily Net Sales increased substantially during P07, while other categories also increased. The promotion is therefore associated with stronger Oud sales, but a simple before/after comparison cannot establish that the promotion caused the increase because Ramadan seasonality, overall sales trends and other concurrent effects may also have contributed.